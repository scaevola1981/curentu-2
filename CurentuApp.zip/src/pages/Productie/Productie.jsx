import React, { useState, useCallback, useEffect, useRef } from "react";
import NavBar from "../../Componente/NavBar/NavBar";
import Modal from "../../Componente/Modal";
import styles from "./Productie.module.css";

const API_URL = "http://localhost:3001/api";

const Productie = () => {
  const [retete, setRetete] = useState([]);
  const [stocMateriale, setStocMateriale] = useState([]);
  const [fermentatoare, setFermentatoare] = useState([]);
  const [selectedReteta, setSelectedReteta] = useState(null);
  const [selectedFermentator, setSelectedFermentator] = useState(null);
  const [cantitateProdusa, setCantitateProdusa] = useState("");
  const [stocVerificat, setStocVerificat] = useState(false);
  const [consumMateriale, setConsumMateriale] = useState([]);
  const [materialeInsuficiente, setMaterialeInsuficiente] = useState([]);
  const [canProduce, setCanProduce] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const step1Ref = useRef(null);
  const step2Ref = useRef(null);
  const step3Ref = useRef(null);
  const step4Ref = useRef(null);
  const step5Ref = useRef(null);

  // --- Load Rețete ---
  const loadRetete = useCallback(async () => {
    try {
      const res = await fetch(`${API_URL}/retete-bere`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setRetete(Array.isArray(data) ? data : []);
    } catch (err) {
      setError("Eroare la încărcarea rețetelor: " + err.message);
    }
  }, []);

  // --- Load Materii Prime ---
  const loadMateriale = useCallback(async () => {
    try {
      const res = await fetch(`${API_URL}/materii-prime`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setStocMateriale(data.map((m) => ({ ...m, cantitate: Number(m.cantitate) })));
    } catch (err) {
      setError("Eroare la încărcarea materialelor: " + err.message);
    }
  }, []);

  // --- Load Fermentatoare ---
  const loadFermentatoare = useCallback(async () => {
    try {
      const res = await fetch(`${API_URL}/fermentatoare`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setFermentatoare(data);
    } catch (err) {
      setError("Eroare la încărcarea fermentatoarelor: " + err.message);
    }
  }, []);

  // --- Selectări ---
  const selectReteta = (r) => {
    setSelectedReteta(r);
    setSelectedFermentator(null);
    setCantitateProdusa("");
    setStocVerificat(false);
    resetVerificare();
    setError("");
    setSuccess("");
  };

  const selectFermentator = (f) => {
    if (f.ocupat) return setError("Fermentatorul este deja ocupat!");
    setSelectedFermentator(f);
    setCantitateProdusa("");
    setStocVerificat(false);
    resetVerificare();
    setError("");
    setSuccess("");
  };

  const handleCantitateChange = (e) => {
    setCantitateProdusa(e.target.value);
    setStocVerificat(false);
    resetVerificare();
    setError("");
    setSuccess("");
  };

  // --- Verifică stoc ---
  const verificaStoc = useCallback(() => {
    if (!selectedReteta || !selectedFermentator || !cantitateProdusa) {
      setError("Completați toți pașii înainte de verificare!");
      return;
    }

    const cant = parseInt(cantitateProdusa);
    if (cant <= 0) return setError("Cantitate invalidă!");
    if (cant > selectedFermentator.capacitate)
      return setError(`Cantitatea depășește capacitatea fermentatorului (${selectedFermentator.capacitate}L)!`);

    const factor = cant / selectedReteta.rezultat.cantitate;
    const consum = selectedReteta.ingrediente.map((ing) => {
      let c = Number((ing.cantitate * factor).toFixed(2));
      let unit = ing.unitate;
      if (ing.tip === "drojdie" && unit === "kg") {
        c = Number((c * 1000).toFixed(2));
        unit = "g";
      }
      return { denumire: ing.denumire, cantitate: c, unitate: unit, tip: ing.tip };
    });

    const insuf = consum
      .map((i) => {
        const stoc = stocMateriale.find((m) => m.denumire === i.denumire && m.unitate === i.unitate);
        if (!stoc || stoc.cantitate < i.cantitate) {
          return {
            denumire: i.denumire,
            cantitateNecesara: i.cantitate,
            cantitateDisponibila: stoc ? stoc.cantitate : 0,
            unitate: i.unitate,
          };
        }
        return null;
      })
      .filter(Boolean);

    setConsumMateriale(consum);
    setMaterialeInsuficiente(insuf);
    setCanProduce(insuf.length === 0);
    setStocVerificat(true);
  }, [selectedReteta, selectedFermentator, cantitateProdusa, stocMateriale]);

  // --- Confirmare producție ---
  const confirmaProductia = useCallback(async () => {
    if (!canProduce) return setError("Nu se poate produce: ingrediente insuficiente.");

    try {
      for (const ing of consumMateriale) {
        const stoc = stocMateriale.find((m) => m.denumire === ing.denumire && m.unitate === ing.unitate);
        if (stoc) {
          await fetch(`${API_URL}/materii-prime/${stoc.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              ...stoc,
              cantitate: Number((stoc.cantitate - ing.cantitate).toFixed(2)),
            }),
          });
        }
      }

      const updatedFermentator = {
        ...selectedFermentator,
        ocupat: true,
        reteta: selectedReteta.denumire,
        cantitate: parseInt(cantitateProdusa),
        dataInceput: new Date().toISOString(),
      };

      await fetch(`${API_URL}/fermentatoare/${selectedFermentator.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedFermentator),
      });

      setSuccess("Producție confirmată și transferată în fermentator!");
      setError("");
      resetTot();
      await Promise.all([loadMateriale(), loadFermentatoare()]);
    } catch (err) {
      setError("Eroare la confirmarea producției: " + err.message);
    }
  }, [canProduce, consumMateriale, selectedFermentator, selectedReteta, cantitateProdusa, stocMateriale, loadMateriale, loadFermentatoare]);

  const resetVerificare = () => {
    setConsumMateriale([]);
    setMaterialeInsuficiente([]);
    setCanProduce(false);
  };

  const resetTot = () => {
    setSelectedReteta(null);
    setSelectedFermentator(null);
    setCantitateProdusa("");
    setStocVerificat(false);
    resetVerificare();
  };

  // --- Auto scroll pe pași ---
  useEffect(() => {
    const scrollTo = (ref) => ref.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    if (selectedReteta && !selectedFermentator) scrollTo(step2Ref);
    else if (selectedFermentator && !cantitateProdusa) scrollTo(step3Ref);
    else if (cantitateProdusa && !stocVerificat) scrollTo(step4Ref);
    else if (stocVerificat && canProduce) scrollTo(step5Ref);
  }, [selectedReteta, selectedFermentator, cantitateProdusa, stocVerificat, canProduce]);

  // --- Init ---
  useEffect(() => {
    loadRetete();
    loadMateriale();
    loadFermentatoare();
  }, [loadRetete, loadMateriale, loadFermentatoare]);

  return (
    <>
      <NavBar />
      <div className={styles.container}>
        {/* 🔹 Modals pentru feedback */}
        {error && <Modal title="Eroare" message={error} type="error" onClose={() => setError("")} />}
        {success && (
          <Modal title="Succes" message={success} type="success" onClose={() => setSuccess("")} />
        )}

        <h1>Planificare Producție</h1>

        {/* Starea fermentatoarelor */}
        <div className={styles.fermentatorStatus}>
          <h2>Starea Fermentatoarelor</h2>
          <div className={styles.fermentatoareGrid}>
            {fermentatoare.map((f) => (
              <div
                key={f.id}
                className={`${styles.fermentatorCard} ${f.ocupat ? styles.ocupat : styles.liber}`}
                style={{
                  backgroundImage: `url(${f.imagine})`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                }}
              >
                <div className={styles.fermentatorCardOverlay}>
                  <h3>{f.nume}</h3>
                  <p>Capacitate: {f.capacitate}L</p>
                  {f.ocupat ? (
                    <>
                      <p><strong>Rețetă:</strong> {f.reteta}</p>
                      <p><strong>Cantitate:</strong> {f.cantitate}L</p>
                      <p><strong>Data:</strong> {new Date(f.dataInceput).toLocaleDateString()}</p>
                    </>
                  ) : (
                    <p className={styles.statusLiber}>Disponibil</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pas 1: Select rețetă */}
        <div className={styles.stepSection} ref={step1Ref}>
          <h2>Pas 1: Selectați Rețeta</h2>
          <div className={styles.reteteContainer}>
            {retete.length === 0 ? (
              <p>Nu s-au încărcat rețetele.</p>
            ) : (
              retete.map((r) => (
                <div
                  key={r.id}
                  className={`${styles.retetaCard} ${selectedReteta?.id === r.id ? styles.selected : ""}`}
                  onClick={() => selectReteta(r)}
                  style={{
                    backgroundImage: r.image ? `url(${r.image})` : "none",
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                  }}
                >
                  <div className={styles.retetaCardOverlay}>
                    <h3>{r.denumire}</h3>
                    <p>Tip: {r.tip}</p>
                    <p>Durată: {r.durata} zile</p>
                    <p>Rezultat: {r.rezultat.cantitate} {r.rezultat.unitate}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Pas 2 */}
        {selectedReteta && (
          <div className={styles.stepSection} ref={step2Ref}>
            <h2>Pas 2: Selectați Fermentatorul</h2>
            <div className={styles.fermentatoareGrid}>
              {fermentatoare.filter((f) => !f.ocupat).map((f) => (
                <div
                  key={f.id}
                  className={`${styles.fermentatorSelectCard} ${
                    selectedFermentator?.id === f.id ? styles.selectedFermentator : ""
                  }`}
                  onClick={() => selectFermentator(f)}
                  style={{
                    backgroundImage: `url(${f.imagine})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                  }}
                >
                  <div className={styles.fermentatorSelectOverlay}>
                    <h5>{f.nume}</h5>
                    <p>Capacitate: {f.capacitate}L</p>
                    <p className={styles.disponibil}>Disponibil</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Pas 3 */}
        {selectedFermentator && (
          <div className={styles.stepSection} ref={step3Ref}>
            <h2>Pas 3: Introduceți Cantitatea</h2>
            <input
              type="number"
              value={cantitateProdusa}
              onChange={handleCantitateChange}
              placeholder={`Max: ${selectedFermentator.capacitate}L`}
              className={styles.input}
            />
          </div>
        )}

        {/* Pas 4 */}
        {cantitateProdusa && (
          <div className={styles.stepSection} ref={step4Ref}>
            <h2>Pas 4: Verificați Stocul</h2>
            <button onClick={verificaStoc} className={styles.button}>
              Verifică Stocul
            </button>
            {stocVerificat && (
              <ul>
                {consumMateriale.map((i, idx) => (
                  <li
                    key={idx}
                    className={
                      materialeInsuficiente.find((m) => m.denumire === i.denumire)
                        ? styles.ingredientInsuficient
                        : styles.ingredientOk
                    }
                  >
                    {i.denumire}: {i.cantitate} {i.unitate}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        {/* Pas 5 */}
        {stocVerificat && canProduce && (
          <div className={styles.stepSection} ref={step5Ref}>
            <h2>Pas 5: Confirmare</h2>
            <button onClick={confirmaProductia} className={styles.buttonConfirm}>
              🚀 Pornește Producția
            </button>
          </div>
        )}
      </div>
    </>
  );
};

export default Productie;
