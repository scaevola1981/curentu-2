import React, { useEffect, useState } from "react";
import NavBar from "../../Componente/NavBar/NavBar.jsx";
import styles from "./Rebuturi.module.css";

const API_URL = "http://localhost:3001";

const Rebuturi = () => {
  const [rebuturi, setRebuturi] = useState([]);
  const [totalLitri, setTotalLitri] = useState(0);
  const [totalCapace, setTotalCapace] = useState(0);
  const [totalEtichete, setTotalEtichete] = useState(0);
  const [totalCutii, setTotalCutii] = useState(0);
  const [totalSticle, setTotalSticle] = useState(0);
  const [totalKeguri, setTotalKeguri] = useState(0);
  const [error, setError] = useState("");

  useEffect(() => {
    loadRebuturi();
  }, []);

    const loadRebuturi = async () => {
  try {
    const res = await fetch(`${API_URL}/api/rebuturi`);
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    const rebuturiData = await res.json();
    setRebuturi(rebuturiData);

    const litri = rebuturiData.reduce(
      (sum, rebut) => sum + parseFloat(rebut.cantitate || 0),
      0
    );

    const capace = rebuturiData.reduce(
      (sum, rebut) => sum + (rebut.materiale?.capace || 0),
      0
    );

    const etichete = rebuturiData.reduce(
      (sum, rebut) => sum + (rebut.materiale?.etichete || 0),
      0
    );

    const cutii = rebuturiData.reduce(
      (sum, rebut) => sum + (rebut.materiale?.cutii || 0),
      0
    );

    const sticle = rebuturiData.reduce(
      (sum, rebut) => sum + (rebut.materiale?.sticle || 0),
      0
    );

    const keguri = rebuturiData.reduce(
      (sum, rebut) => sum + (rebut.materiale?.keguri || 0),
      0
    );

    setTotalLitri(litri);
    setTotalCapace(capace);
    setTotalEtichete(etichete);
    setTotalCutii(cutii);
    setTotalSticle(sticle);
    setTotalKeguri(keguri);
    setError("");

  } catch (error) {
    setError(`Eroare la încărcarea rebuturilor: ${error.message}`);
  }
};


  // 🔥 ȘTERGERE INDIVIDUALĂ A UNUI REBUT (CARD)
  const handleDeleteRebut = async (id) => {
  if (!window.confirm("Sigur doriți să ștergeți acest rebut?")) return;

  try {
    const res = await fetch(`${API_URL}/api/rebuturi/${id}`, {
      method: "DELETE",
    });

    if (!res.ok) throw new Error("Eroare la ștergerea rebutului");

    setRebuturi((prev) => prev.filter((r) => r.id !== id));
  } catch (error) {
    setError(`Eroare la ștergerea rebutului: ${error.message}`);
  }
};

  // 🔥 Șterge TOT (există deja)
  const handleDeleteAllRebuturi = async () => {
    if (
      !window.confirm(
        "Sigur doriți să ștergeți toate rebuturile? Această acțiune nu poate fi anulată!"
      )
    )
      return;

    try {
      const res = await fetch(`${API_URL}/api/iesiri-bere`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error(`HTTP error ${res.status}`);

      setRebuturi([]);
      setTotalLitri(0);
      setTotalCapace(0);
      setTotalEtichete(0);
      setTotalCutii(0);
      setTotalSticle(0);
      setTotalKeguri(0);
      setError("Toate rebuturile au fost șterse cu succes!");
    } catch (error) {
      setError(`Eroare la ștergerea rebuturilor: ${error.message}`);
    }
  };

  return (
    <>
      <NavBar />
      <div className={styles.container}>
        {error && (
          <div className={styles.modal}>
            <div className={styles.modalContent}>
              <p>{error}</p>
              <button
                className={styles.modalButton}
                onClick={() => setError("")}
              >
                Închide
              </button>
            </div>
          </div>
        )}

        <h1 className={styles.title}>Rebuturi și Pierderi</h1>

        <div className={styles.toolbar}>
          {import.meta.env.MODE === "production" && (
            <button
              className={styles.buttonDeleteAll}
              onClick={handleDeleteAllRebuturi}
            >
              Șterge Toate Rebuturile
            </button>
          )}
        </div>

        {rebuturi.length === 0 ? (
          <p className={styles.noData}>
            Nu există rebuturi sau pierderi înregistrate.
          </p>
        ) : (
          <>
            {/* === CARDURI INDIVIDUALE === */}
            <div className={styles.gridContainer}>
              {rebuturi.map((rebut) => (
                <div key={rebut.id} className={styles.lotCard}>
                  
                  {/* 🔥 BUTON DE ȘTERGERE CARD */}
                  <button
                    className={styles.deleteCardBtn}
                    onClick={() => handleDeleteRebut(rebut.id)}
                  >
                    ✕
                  </button>

                  <div className={styles.cardHeader}>
                    <h2>{rebut.reteta || "Necunoscută"}</h2>
                    <span className={styles.lotDate}>
                      {new Date(rebut.dataIesire).toLocaleDateString("ro-RO")}
                    </span>
                  </div>

                  <div className={styles.cardSummary}>
                    <div className={styles.summaryItem}>
                      <span className={styles.summaryLabel}>Cantitate:</span>
                      <span className={styles.summaryValue}>
                        {parseFloat(rebut.cantitate || 0).toFixed(2)} L
                      </span>
                    </div>

                    <div className={styles.summaryItem}>
                      <span className={styles.summaryLabel}>Ambalaj:</span>
                      <span className={styles.summaryValue}>{rebut.ambalaj}</span>
                    </div>

                    {rebut.boxType && (
                      <div className={styles.summaryItem}>
                        <span className={styles.summaryLabel}>Cutie:</span>
                        <span className={styles.summaryValue}>
                          {rebut.boxType}
                        </span>
                      </div>
                    )}

                    <div className={styles.summaryItem}>
                      <span className={styles.summaryLabel}>Unități:</span>
                      <span className={styles.summaryValue}>
                        {rebut.numarUnitatiScoase || "-"}
                      </span>
                    </div>

                    {rebut.detaliiIesire && (
                      <div className={styles.summaryItem}>
                        <span className={styles.summaryLabel}>Detalii:</span>
                        <span className={styles.summaryValue}>
                          {rebut.detaliiIesire}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className={styles.materialsGrid}>
                    <div className={styles.materialItem}>
                      <span className={styles.materialLabel}>Capace</span>
                      <span className={styles.materialValue}>
                        {rebut.materiale?.capace || 0}
                      </span>
                    </div>

                    <div className={styles.materialItem}>
                      <span className={styles.materialLabel}>Etichete</span>
                      <span className={styles.materialValue}>
                        {rebut.materiale?.etichete || 0}
                      </span>
                    </div>

                    <div className={styles.materialItem}>
                      <span className={styles.materialLabel}>Cutii</span>
                      <span className={styles.materialValue}>
                        {rebut.materiale?.cutii || 0}
                      </span>
                    </div>

                    <div className={styles.materialItem}>
                      <span className={styles.materialLabel}>Sticle</span>
                      <span className={styles.materialValue}>
                        {rebut.materiale?.sticle || 0}
                      </span>
                    </div>

                    <div className={styles.materialItem}>
                      <span className={styles.materialLabel}>Keguri</span>
                      <span className={styles.materialValue}>
                        {rebut.materiale?.keguri || 0}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* === TOTAL GENERAL === */}
            <div className={styles.totalSection}>
              <h3>Total General</h3>
              <div className={styles.totalGrid}>
                <div className={styles.totalItem}>
                  <span className={styles.totalLabel}>Litri:</span>
                  <span className={styles.totalValue}>
                    {totalLitri.toFixed(2)} L
                  </span>
                </div>

                <div className={styles.totalItem}>
                  <span className={styles.totalLabel}>Capace:</span>
                  <span className={styles.totalValue}>{totalCapace}</span>
                </div>

                <div className={styles.totalItem}>
                  <span className={styles.totalLabel}>Etichete:</span>
                  <span className={styles.totalValue}>{totalEtichete}</span>
                </div>

                <div className={styles.totalItem}>
                  <span className={styles.totalLabel}>Cutii:</span>
                  <span className={styles.totalValue}>{totalCutii}</span>
                </div>

                <div className={styles.totalItem}>
                  <span className={styles.totalLabel}>Sticle:</span>
                  <span className={styles.totalValue}>{totalSticle}</span>
                </div>

                <div className={styles.totalItem}>
                  <span className={styles.totalLabel}>Keguri:</span>
                  <span className={styles.totalValue}>{totalKeguri}</span>
                </div>

                <div className={styles.totalItem}>
                  <span className={styles.totalLabel}>Total rebuturi:</span>
                  <span className={styles.totalValue}>{rebuturi.length}</span>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default Rebuturi;
